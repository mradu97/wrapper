package wrapperdemo;

public class WrapperDemo {

    public static void main(String[] args) {

        Integer x = new Integer("234");
        Integer y = new Integer(156);
        
        int z = Integer.parseInt("455");
        Integer w = Integer.valueOf("655");
        
        Integer p = Integer.decode("0x243");
        
        System.out.println(p);
        
        System.out.println("Binary representation of x is "+
                Integer.toBinaryString(x));
        
        System.out.println("Octal representation of x is "+
                Integer.toOctalString(x));
        
        System.out.println("Hexadecimal representation of x is "+
                Integer.toHexString(x));
        
        System.out.println(x.intValue());
        
        System.out.println(x.doubleValue());
        
        System.out.println(x.floatValue());
        
        System.out.println(x.longValue());
        
        System.out.println(x.shortValue());
        
        System.out.println(x.byteValue());
    }
}
